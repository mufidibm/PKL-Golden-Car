<div class="flex items-center px-4 py-2">
    <img 
        src="{{ asset('images/logo.jpg') }}" 
        alt="Logo" 
        class="h-10 w-auto"
    >
</div>