<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;
use Illuminate\Support\Facades\View;
use App\Models\Setting;
use Filament\Support\Facades\FilamentView;
use Filament\Navigation\NavigationItem;
use Carbon\Carbon;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     */
    public function register(): void
    {
        //
    }

    /**
     * Bootstrap any application services.
     */
    public function boot(): void
    {
        $setting = Setting::first();
        setlocale(LC_TIME, 'id_ID.utf8', 'id_ID', 'id');
        Carbon::setLocale('id');

        View::share('setting', $setting);

        FilamentView::registerRenderHook(
            'panels::topbar.start',
            fn(): string => view('filament.resources.components.topbar-logo')->render()
        );
    }
}
