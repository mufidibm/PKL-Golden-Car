<p
    class="fi-section-header-description text-sm text-gray-500 dark:text-gray-400"
>
    <?php echo e($slot); ?>

</p>
<?php /**PATH D:\RPL B 27\PKL ALPHA MEDIANUSA SOLUSINDO\bengkel 2\bengkel\resources\views\vendor\filament\components\section\description.blade.php ENDPATH**/ ?>