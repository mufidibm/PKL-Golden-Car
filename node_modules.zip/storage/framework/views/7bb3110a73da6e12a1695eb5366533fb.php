<?php
    $setting = \App\Models\Setting::first();
?>

<?php if($setting && $setting->getFirstMediaUrl('logo')): ?>
    <div class="flex relative justify-center items-center h-full max-h-12">
        <img src="<?php echo e($setting->getFirstMediaUrl('logo')); ?>"
             alt="Logo"
             class="h-full w-auto max-h-full object-contain"
        />
    </div>
<?php endif; ?>
<?php /**PATH D:\laragon\www\bengkel\resources\views/filament/resources/components/topbar-logo.blade.php ENDPATH**/ ?>