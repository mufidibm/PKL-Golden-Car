<?php
    $setting = \App\Models\Setting::first();
?>

<?php if($setting): ?>
    <table>
        <tr>
            <td colspan="5" style="font-size: 16px; font-weight: bold;"><?php echo e($setting->nama_bengkel ?? 'Aplikasi Bengkel'); ?></td>
        </tr>
        <tr>
            <td colspan="5"><?php echo e($setting->alamat ?? '-'); ?></td>
        </tr>
        <tr>
            <td colspan="5">Telp: <?php echo e($setting->telepon ?? '-'); ?></td>
        </tr>
    </table>
    <br>
<?php endif; ?>

<table>
    <tr><td colspan="5" style="font-size: 18px; font-weight: bold;">Laporan Pembayaran</td></tr>
    <tr>
        <td><strong>Periode:</strong></td>
        <td><?php echo e(isset($tanggalMulai) && isset($tanggalSelesai) ? date('d-m-Y', strtotime($tanggalMulai)) . ' s/d ' . date('d-m-Y', strtotime($tanggalSelesai)) : '-'); ?></td>
    </tr>
    <tr>
        <td><strong>Jumlah Transaksi:</strong></td>
        <td><?php echo e($jumlahTransaksi); ?></td>
    </tr>
</table>

<br>

<table border="1">
    <thead>
        <tr>
            <th style="background: #f0f0f0;">Tanggal</th>
            <th style="background: #f0f0f0;">Customer</th>
            <th style="background: #f0f0f0;">No Polisi</th>
            <th style="background: #f0f0f0;">Metode</th>
            <th style="background: #f0f0f0;">Total Bayar</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($row->created_at->format('d-m-Y H:i')); ?></td>
                <td><?php echo e($row->transaksiMasuk->kendaraan->customer->nama ?? '-'); ?></td>
                <td><?php echo e($row->transaksiMasuk->kendaraan->no_polisi ?? '-'); ?></td>
                <td><?php echo e($row->metodePembayaran->nama_metode ?? '-'); ?></td>
                <td><?php echo e($row->total_bayar); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>

<br>

<table>
    <tr>
        <td><strong>Total Pembayaran:</strong></td>
        <td>Rp <?php echo e(number_format($totalPembayaran)); ?></td>
    </tr>
</table>
<?php /**PATH D:\RPL B 27\PKL ALPHA MEDIANUSA SOLUSINDO\bengkel 2\bengkel\resources\views\exports\laporan-pembayaran-excel.blade.php ENDPATH**/ ?>