<?php if(isset($transaksi)): ?>
    <hr>

    <form action="<?php echo e(route('pembayaran.dari-transaksi', ['transaksi' => $transaksi->id])); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <button type="submit" class="btn btn-primary">
            <i class="fas fa-cash-register"></i> Proses Pembayaran
        </button>
    </form>
<?php endif; ?><?php /**PATH D:\RPL B 27\PKL ALPHA MEDIANUSA SOLUSINDO\bengkel 2\bengkel\resources\views\transaksi\edit.blade.php ENDPATH**/ ?>