<div
    <?php echo e($attributes
            ->merge($getExtraAttributes(), escape: false)
            ->class([
                'fi-ta-color flex flex-wrap gap-1.5',
                'px-3 py-4' => ! $isInline(),
            ])); ?>

>
    <?php $__currentLoopData = \Illuminate\Support\Arr::wrap($getState()); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $state): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php
            $itemIsCopyable = $isCopyable($state);
            $copyableState = $getCopyableState($state) ?? $state;
            $copyMessage = $getCopyMessage($state);
            $copyMessageDuration = $getCopyMessageDuration($state);
        ?>

        <div
            <?php if($itemIsCopyable): ?>
                x-on:click="
                    window.navigator.clipboard.writeText(<?php echo \Illuminate\Support\Js::from($copyableState)->toHtml() ?>)
                    $tooltip(<?php echo \Illuminate\Support\Js::from($copyMessage)->toHtml() ?>, { timeout: <?php echo \Illuminate\Support\Js::from($copyMessageDuration)->toHtml() ?> })
                "
            <?php endif; ?>
            class="<?php echo \Illuminate\Support\Arr::toCssClasses([
                'fi-ta-color-item h-6 w-6 rounded-md',
                'cursor-pointer' => $itemIsCopyable,
            ]); ?>"
            style="<?php echo \Illuminate\Support\Arr::toCssStyles([
                "background-color: {$state}" => $state,
            ]) ?>"
        ></div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php /**PATH D:\RPL B 27\PKL ALPHA MEDIANUSA SOLUSINDO\bengkel 2\bengkel\vendor\filament\tables\resources\views\columns\color-column.blade.php ENDPATH**/ ?>