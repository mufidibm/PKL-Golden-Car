<h3
    <?php echo e($attributes->class(['fi-no-notification-title text-sm font-medium text-gray-950 dark:text-white'])); ?>

>
    <?php echo e($slot); ?>

</h3>
<?php /**PATH D:\RPL B 27\PKL ALPHA MEDIANUSA SOLUSINDO\bengkel 2\bengkel\vendor\filament\notifications\resources\views/components/title.blade.php ENDPATH**/ ?>