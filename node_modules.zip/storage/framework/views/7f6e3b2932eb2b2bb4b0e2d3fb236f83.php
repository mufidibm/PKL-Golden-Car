

<?php $__env->startSection('content'); ?>
    <h2>Detail Kendaraan</h2>
    <p><strong>No Polisi:</strong> <?php echo e($kendaraan->no_polisi); ?></p>
    <p><strong>Tipe:</strong> <?php echo e($kendaraan->tipe); ?></p>
    <p><strong>Merek:</strong> <?php echo e($kendaraan->merek); ?></p>
    <p><strong>Tahun:</strong> <?php echo e($kendaraan->tahun); ?></p>
    <p><strong>Customer:</strong> <?php echo e($kendaraan->customer->nama); ?></p>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\RPL B 27\PKL ALPHA MEDIANUSA SOLUSINDO\bengkel 2\bengkel\resources\views\kendaraan\detail.blade.php ENDPATH**/ ?>