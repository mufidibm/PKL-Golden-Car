<p
    <?php echo e($attributes->class(['fi-ta-empty-state-description text-sm text-gray-500 dark:text-gray-400'])); ?>

>
    <?php echo e($slot); ?>

</p>
<?php /**PATH D:\RPL B 27\PKL ALPHA MEDIANUSA SOLUSINDO\bengkel 2\bengkel\vendor\filament\tables\resources\views/components/empty-state/description.blade.php ENDPATH**/ ?>