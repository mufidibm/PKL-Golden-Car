<time
    <?php echo e($attributes->class(['fi-no-notification-date text-sm text-gray-500 dark:text-gray-400'])); ?>

>
    <?php echo e($slot); ?>

</time>
<?php /**PATH D:\RPL B 27\PKL ALPHA MEDIANUSA SOLUSINDO\bengkel 2\bengkel\vendor\filament\notifications\resources\views\components\date.blade.php ENDPATH**/ ?>