<?php
    $setting = \App\Models\Setting::first();
    $logoUrl = $setting?->getFirstMediaUrl('logo');
?>

<div class="flex flex-col items-center justify-center mb-6">
    <?php if($logoUrl): ?>
        <img src="<?php echo e($logoUrl); ?>" alt="Logo" style="height: 80px; width: 80px; object-fit: cover; border-radius: 12px; margin-bottom: 16px;">
    <?php endif; ?>
    <h1 class="text-2xl font-bold"><?php echo e($setting->nama_bengkel ?? 'Aplikasi Bengkel'); ?></h1>
</div>

<div>DEBUG: <?php echo e($logoUrl); ?></div>

<img src="<?php echo e(asset('storage/' . $setting->logo)); ?>" alt="Logo" class="mb-4 w-32 mx-auto" />

<?php echo e($slot); ?> <?php /**PATH D:\RPL B 27\PKL ALPHA MEDIANUSA SOLUSINDO\bengkel 2\bengkel\resources\views\vendor\filament\auth\login.blade.php ENDPATH**/ ?>