<h3
    class="fi-section-header-heading text-base font-semibold leading-6 text-gray-950 dark:text-white"
>
    <?php echo e($slot); ?>

</h3>
<?php /**PATH D:\RPL B 27\PKL ALPHA MEDIANUSA SOLUSINDO\bengkel 2\bengkel\resources\views\vendor\filament\components\section\heading.blade.php ENDPATH**/ ?>