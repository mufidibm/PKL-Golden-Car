<?php
    $setting = \App\Models\Setting::first();
?>
<?php if($setting): ?>
    <div style="display: flex; align-items: center; margin-bottom: 24px; border-bottom: 2px solid #333; padding-bottom: 16px;">
        <div>
            <div style="font-size: 1.5em; font-weight: bold;"><?php echo e($setting->nama_bengkel ?? 'Aplikasi Bengkel'); ?></div>
            <div style="font-size: 1em;"><?php echo e($setting->alamat ?? '-'); ?></div>
            <div style="font-size: 1em;">Telp: <?php echo e($setting->telepon ?? '-'); ?></div>
        </div>
    </div>
<?php endif; ?>
<h2>Laporan Pendapatan</h2>
<p><strong>Periode:</strong> <?php echo e(isset($tanggalMulai) && isset($tanggalSelesai) ? date('d-m-Y', strtotime($tanggalMulai)) . ' s/d ' . date('d-m-Y', strtotime($tanggalSelesai)) : '-'); ?></p>
<p><strong>Jumlah Transaksi:</strong> <?php echo e($jumlahTransaksi); ?></p>
<table border="1" cellspacing="0" cellpadding="4" width="100%">
    <thead>
        <tr>
            <th>Tanggal</th>
            <th>Customer</th>
            <th>Metode</th>
            <th>Total Bayar</th>
            <th>Total Pendapatan</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
                $pendapatan = 0;
                foreach ($row->detail as $detail) {
                    $hargaBeli = $detail->barang->harga_beli ?? 0;
                    $pendapatan += (($detail->harga_satuan - $hargaBeli) * $detail->qty);
                }
            ?>
            <tr>
                <td><?php echo e($row->created_at->format('d-m-Y H:i')); ?></td>
                <td><?php echo e($row->transaksiMasuk->kendaraan->customer->nama ?? '-'); ?></td>
                <td><?php echo e($row->metodePembayaran->nama_metode ?? '-'); ?></td>
                <td style="text-align:center">Rp <?php echo e(number_format($row->total_bayar)); ?></td>
                <td style="text-align:center">Rp <?php echo e(number_format($pendapatan)); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<p><strong>Total Pendapatan:</strong> Rp <?php echo e(number_format($totalPendapatan)); ?></p> <?php /**PATH D:\RPL B 27\PKL ALPHA MEDIANUSA SOLUSINDO\bengkel 2\bengkel\resources\views\exports\laporan-pendapatan-pdf.blade.php ENDPATH**/ ?>