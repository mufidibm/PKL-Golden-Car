<div
    <?php echo e($attributes
            ->merge($getExtraAttributes(), escape: false)
            ->class([
                'flex gap-6',
                match ($getFromBreakpoint()) {
                    'sm' => 'flex-col sm:flex-row sm:items-start',
                    'md' => 'flex-col md:flex-row md:items-start',
                    'lg' => 'flex-col lg:flex-row lg:items-start',
                    'xl' => 'flex-col xl:flex-row xl:items-start',
                    '2xl' => 'flex-col 2xl:flex-row 2xl:items-start',
                    default => 'items-start',
                },
            ])); ?>

>
    <?php $__currentLoopData = $getChildComponentContainers(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $container): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php $__currentLoopData = $container->getComponents(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $component): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div
                class="<?php echo \Illuminate\Support\Arr::toCssClasses([
                    'w-full flex-1' => $component->canGrow(),
                ]); ?>"
            >
                <?php echo e($component); ?>

            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php /**PATH D:\RPL B 27\PKL ALPHA MEDIANUSA SOLUSINDO\bengkel 2\bengkel\vendor\filament\infolists\resources\views\components\split.blade.php ENDPATH**/ ?>