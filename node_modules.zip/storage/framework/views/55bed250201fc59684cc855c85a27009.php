<td
    <?php echo e($attributes->class(['px-3 py-2 text-sm font-medium text-gray-950 dark:text-white sm:first-of-type:ps-6'])); ?>

>
    <?php echo e($slot); ?>

</td>
<?php /**PATH D:\RPL B 27\PKL ALPHA MEDIANUSA SOLUSINDO\bengkel 2\bengkel\vendor\filament\tables\resources\views\components\summary\header-cell.blade.php ENDPATH**/ ?>