<?php if (isset($component)) { $__componentOriginal166a02a7c5ef5a9331faf66fa665c256 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal166a02a7c5ef5a9331faf66fa665c256 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'filament-panels::components.page.index','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('filament-panels::page'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="mb-6">
        <form method="GET" class="mb-6">
            <div class="flex flex-col sm:flex-row gap-4 items-end">
                <div class="flex-1">
                    <label class="block text-sm font-medium">Tanggal Mulai</label>
                    <input type="date" name="tanggalMulai" value="<?php echo e(request('tanggalMulai', $tanggalMulai)); ?>" class="border rounded px-2 py-1 w-full" />
                </div>
                <div class="flex-1">
                    <label class="block text-sm font-medium">Tanggal Selesai</label>
                    <input type="date" name="tanggalSelesai" value="<?php echo e(request('tanggalSelesai', $tanggalSelesai)); ?>" class="border rounded px-2 py-1 w-full" />
                </div>
                <div class="flex-1">
                    <label class="block text-sm font-medium">Customer</label>
                    <select name="customerId" class="border rounded px-2 py-1 w-full">
                        <option value="">Semua Customer</option>
                        <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $nama): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($id); ?>" <?php echo e(request('customerId', $customerId) == $id ? 'selected' : ''); ?>><?php echo e($nama); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="flex-1">
                    <label class="block text-sm font-medium">Metode Pembayaran</label>
                    <select name="metodePembayaranId" class="border rounded px-2 py-1 w-full">
                        <option value="">Semua Metode</option>
                        <?php $__currentLoopData = $metodePembayaranList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $nama): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($id); ?>" <?php echo e(request('metodePembayaranId', $metodePembayaranId) == $id ? 'selected' : ''); ?>><?php echo e($nama); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="flex items-end">
                    <button type="submit"
                        style="background:#198754;color:#fff;font-weight:bold;padding:0.5rem 1.5rem;border-radius:0.375rem;border:none;min-width:90px;">
                        Filter
                    </button>
                </div>
            </div>
        </form>
    </div>

    <div class="flex gap-2 mb-4">
        <a href="<?php echo e(route('laporan-pendapatan.export-pdf', request()->query())); ?>"
           style="background:#198754;color:#fff;font-weight:bold;padding:0.5rem 1.5rem;border-radius:0.375rem;border:none;min-width:90px;display:inline-block;text-align:center;text-decoration:none;"
           target="_blank">
            Export PDF
        </a>

        <a href="<?php echo e(route('laporan-pendapatan.export-excel', request()->query())); ?>"
            style="background:#0d6efd;color:#fff;font-weight:bold;padding:0.5rem 1.5rem;border-radius:0.375rem;border:none;min-width:90px;display:inline-block;text-align:center;text-decoration:none;"
            target="_blank">
            Export Excel
        </a>
    </div>

    
    <?php $ringkasan = $this->getRingkasan(); ?>
    <div class="flex flex-wrap gap-8 mb-2">
        <div style="margin-right: 40px">
            <div class="text-sm text-gray-500">Total Pendapatan</div>
            <div class="text-2xl font-bold">Rp <?php echo e(number_format($ringkasan['totalPendapatan'])); ?></div>
        </div>
        <div>
            <div class="text-sm text-gray-500">Jumlah Transaksi</div>
            <div class="text-2xl font-bold"><?php echo e($ringkasan['jumlahTransaksi']); ?></div>
        </div>
    </div>

    <div class="overflow-x-auto mb-6">
        <table class="min-w-full w-full bg-white border border-gray-200 rounded-lg">
            <thead>
                <tr class="bg-gray-100">
                    <th class="px-4 py-2 text-left">Tanggal</th>
                    <th class="px-4 py-2 text-left">Customer</th>
                    <th class="px-4 py-2 text-left">Metode</th>
                    <th class="px-4 py-2 text-center">Total Bayar</th>
                    <th class="px-4 py-2 text-center">Total Pendapatan</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $this->getDataPendapatan(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $pendapatan = 0;
                        foreach ($row->detail as $detail) {
                            $hargaBeli = $detail->barang->harga_beli ?? 0;
                            $pendapatan += (($detail->harga_satuan - $hargaBeli) * $detail->qty);
                        }
                    ?>
                    <tr class="border-b">
                        <td class="px-4 py-2"><?php echo e($row->created_at->format('d-m-Y H:i')); ?></td>
                        <td class="px-4 py-2"><?php echo e($row->transaksiMasuk->kendaraan->customer->nama ?? '-'); ?></td>
                        <td class="px-4 py-2"><?php echo e($row->metodePembayaran->nama_metode ?? '-'); ?></td>
                        <td class="px-4 py-2 text-center">Rp <?php echo e(number_format($row->total_bayar)); ?></td>
                        <td class="px-4 py-2 text-center">Rp <?php echo e(number_format($pendapatan)); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal166a02a7c5ef5a9331faf66fa665c256)): ?>
<?php $attributes = $__attributesOriginal166a02a7c5ef5a9331faf66fa665c256; ?>
<?php unset($__attributesOriginal166a02a7c5ef5a9331faf66fa665c256); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal166a02a7c5ef5a9331faf66fa665c256)): ?>
<?php $component = $__componentOriginal166a02a7c5ef5a9331faf66fa665c256; ?>
<?php unset($__componentOriginal166a02a7c5ef5a9331faf66fa665c256); ?>
<?php endif; ?>
<?php /**PATH D:\RPL B 27\PKL ALPHA MEDIANUSA SOLUSINDO\bengkel 2\bengkel\resources\views\filament\pages\laporan-pendapatan.blade.php ENDPATH**/ ?>