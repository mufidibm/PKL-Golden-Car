<div <?php echo e($attributes->class(['flex gap-x-1'])); ?>>
    <?php echo e($slot); ?>

</div>
<?php /**PATH D:\RPL B 27\PKL ALPHA MEDIANUSA SOLUSINDO\bengkel 2\bengkel\vendor\filament\forms\resources\views\components\rich-editor\toolbar\group.blade.php ENDPATH**/ ?>