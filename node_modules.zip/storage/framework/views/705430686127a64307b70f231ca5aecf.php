<?php $__currentLoopData = $getActions(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $action): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php if($action->isVisible()): ?>
        <?php echo e($action); ?>

    <?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH D:\RPL B 27\PKL ALPHA MEDIANUSA SOLUSINDO\bengkel 2\bengkel\vendor\filament\infolists\resources\views\components\actions\action-container.blade.php ENDPATH**/ ?>