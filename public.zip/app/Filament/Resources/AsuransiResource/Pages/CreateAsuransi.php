<?php

namespace App\Filament\Resources\AsuransiResource\Pages;

use App\Filament\Resources\AsuransiResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateAsuransi extends CreateRecord
{
    protected static string $resource = AsuransiResource::class;
}
