<div
    <?php echo e($attributes->class([
            'flex items-center divide-x divide-gray-950/10 overflow-hidden rounded-lg shadow ring-1 ring-gray-950/10 dark:divide-white/20 dark:ring-white/20',
        ])); ?>

>
    <?php echo e($slot); ?>

</div>
<?php /**PATH D:\RPL B 27\PKL ALPHA MEDIANUSA SOLUSINDO\bengkel 2\bengkel\resources\views/vendor/filament/components/button/group.blade.php ENDPATH**/ ?>