<?php

namespace App\Filament\Resources\PengerjaanSparepartResource\Pages;

use App\Filament\Resources\PengerjaanSparepartResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreatePengerjaanSparepart extends CreateRecord
{
    protected static string $resource = PengerjaanSparepartResource::class;
}
