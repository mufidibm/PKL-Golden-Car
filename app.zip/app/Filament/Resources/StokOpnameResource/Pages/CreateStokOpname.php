<?php

namespace App\Filament\Resources\StokOpnameResource\Pages;

use App\Filament\Resources\StokOpnameResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateStokOpname extends CreateRecord
{
    protected static string $resource = StokOpnameResource::class;
}
